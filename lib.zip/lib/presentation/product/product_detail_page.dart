import 'package:flutter/material.dart';

import '../../core/services/cart_service.dart';
import '../../data/models/product_model.dart';

class ProductDetailPage extends StatefulWidget {
  final ProductModel product;

  const ProductDetailPage({
    super.key,
    required this.product,
  });

  @override
  State<ProductDetailPage> createState() =>
      _ProductDetailPageState();
}

class _ProductDetailPageState
    extends State<ProductDetailPage> {
  final CartService _cartService =
      CartService();

  String selectedSize = '';
  String selectedColor = '';

  int quantity = 1;

  @override
  void initState() {
    super.initState();

    if (widget.product.sizes.isNotEmpty) {
      selectedSize =
          widget.product.sizes.first.toString();
    }

    if (widget.product.colors.isNotEmpty) {
      selectedColor =
          widget.product.colors.first.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.product.name),
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),

        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,

          children: [
            // IMAGE
            ClipRRect(
              borderRadius:
                  BorderRadius.circular(20),

              child: Image.asset(
                widget.product.imageUrl,

                height: 300,

                width: double.infinity,

                fit: BoxFit.cover,

                errorBuilder: (
                  context,
                  error,
                  stackTrace,
                ) {
                  return Container(
                    height: 300,

                    color: Colors.grey.shade800,

                    child: const Center(
                      child: Icon(
                        Icons.image_not_supported,
                        size: 50,
                      ),
                    ),
                  );
                },
              ),
            ),

            const SizedBox(height: 20),

            // NAME
            Text(
              widget.product.name,

              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            // PRICE
            Text(
              'Rp ${widget.product.price}',

              style: const TextStyle(
                fontSize: 24,
                color: Color(0xFFD4AF37),
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            // CATEGORY
            Text(
              'Kategori : ${widget.product.category}',
            ),

            const SizedBox(height: 6),

            // STOCK
            Text(
              'Stok tersedia : ${widget.product.stock}',
              style: const TextStyle(
                color: Colors.grey,
              ),
            ),

            const SizedBox(height: 20),

            // DESCRIPTION
            const Text(
              'Deskripsi',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),

            const SizedBox(height: 8),

            Text(
              widget.product.description,
            ),

            const SizedBox(height: 25),

            // SIZE
            if (widget.product.sizes.isNotEmpty) ...[
              const Text(
                'Pilih Ukuran',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 10),

              Wrap(
                spacing: 10,

                children:
                    widget.product.sizes.map((size) {
                  return ChoiceChip(
                    label: Text(size.toString()),

                    selected:
                        selectedSize ==
                        size.toString(),

                    onSelected: (_) {
                      setState(() {
                        selectedSize =
                            size.toString();
                      });
                    },
                  );
                }).toList(),
              ),

              const SizedBox(height: 25),
            ],

            // COLOR
            if (widget.product.colors.isNotEmpty) ...[
              const Text(
                'Pilih Warna',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 10),

              Wrap(
                spacing: 10,

                children:
                    widget.product.colors.map((color) {
                  return ChoiceChip(
                    label:
                        Text(color.toString()),

                    selected:
                        selectedColor ==
                        color.toString(),

                    onSelected: (_) {
                      setState(() {
                        selectedColor =
                            color.toString();
                      });
                    },
                  );
                }).toList(),
              ),

              const SizedBox(height: 25),
            ],

            // QUANTITY
            const Text(
              'Jumlah Pesanan',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            Row(
              children: [
                IconButton(
                  onPressed: () {
                    if (quantity > 1) {
                      setState(() {
                        quantity--;
                      });
                    }
                  },

                  icon: const Icon(
                    Icons.remove_circle,
                  ),
                ),

                Text(
                  quantity.toString(),

                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                IconButton(
                  onPressed: () {
                    if (quantity <
                        widget.product.stock) {
                      setState(() {
                        quantity++;
                      });
                    }
                  },

                  icon: const Icon(
                    Icons.add_circle,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,

              height: 50,

              child: ElevatedButton(
                onPressed: () async {
                  await _cartService.addToCart(
                    product: widget.product,

                    size: selectedSize,

                    color: selectedColor,

                    quantity: quantity,
                  );

                  if (context.mounted) {
                    ScaffoldMessenger.of(
                      context,
                    ).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Produk berhasil ditambahkan ke keranjang',
                        ),
                      ),
                    );
                  }
                },

                child: const Text(
                  'Tambah ke Keranjang',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}