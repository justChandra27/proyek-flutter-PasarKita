//lib/presentation/seller/products/form_produk_seller_web.dart

import 'package:flutter/material.dart';

class FormProdukSellerWeb extends StatelessWidget {
  const FormProdukSellerWeb({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF5F6FA),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // HEADER
            Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 45,
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: "Cari produk...",
                        prefixIcon: const Icon(Icons.search),
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(
                          borderRadius:
                              BorderRadius.circular(12),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                ),

                const SizedBox(width: 20),

                const Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.end,
                  children: [
                    Text(
                      "Andi Setiawan",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "Verified Merchant",
                      style: TextStyle(
                        color: Colors.black54,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),

                const SizedBox(width: 10),

                const CircleAvatar(
                  radius: 20,
                  backgroundImage: NetworkImage(
                    "https://i.pravatar.cc/150",
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // TITLE
            Row(
              children: [
                const Expanded(
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Produk Saya",
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight:
                              FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 5),
                      Text(
                        "Kelola inventaris dan katalog produk toko Anda",
                        style: TextStyle(
                          color: Colors.black54,
                        ),
                      ),
                    ],
                  ),
                ),

                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        const Color(0xff1D4ED8),
                    padding:
                        const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 18,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: () {},
                  icon: const Icon(
                    Icons.add,
                    color: Colors.white,
                  ),
                  label: const Text(
                    "Tambah Produk",
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // STATISTICS
            Row(
              children: [
                Expanded(
                  child: _statCard(
                    Icons.inventory_2_outlined,
                    "Total Produk",
                    "128",
                    Colors.blue,
                  ),
                ),

                const SizedBox(width: 16),

                Expanded(
                  child: _statCard(
                    Icons.check_circle_outline,
                    "Produk Aktif",
                    "112",
                    Colors.green,
                  ),
                ),

                const SizedBox(width: 16),

                Expanded(
                  child: _statCard(
                    Icons.warning_amber_outlined,
                    "Stok Menipis",
                    "5",
                    Colors.red,
                  ),
                ),

                const SizedBox(width: 16),

                Expanded(
                  child: _statCard(
                    Icons.visibility_outlined,
                    "Dilihat (7hr)",
                    "2.4k",
                    Colors.orange,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius:
                      BorderRadius.circular(18),
                ),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          _filterButton(
                              "Semua Status"),
                          const SizedBox(width: 10),
                          _filterButton(
                              "Kategori: Semua"),
                          const SizedBox(width: 10),

                          TextButton.icon(
                            onPressed: () {},
                            icon: const Icon(
                              Icons.tune,
                              size: 18,
                            ),
                            label: const Text(
                                "Filter Lanjutan"),
                          ),

                          const Spacer(),

                          const Text(
                            "Urutkan:",
                            style: TextStyle(
                              color: Colors.black54,
                            ),
                          ),

                          const SizedBox(width: 8),

                          const Text("Terbaru"),

                          const Icon(
                            Icons.keyboard_arrow_down,
                          ),
                        ],
                      ),
                    ),

                    const Divider(height: 1),

                    Expanded(
                      child: SingleChildScrollView(
                        child: DataTable(
                          headingRowColor:
                              WidgetStateProperty.all(
                            const Color(0xffF8F9FC),
                          ),
                          columns: const [
                            DataColumn(
                              label: Checkbox(
                                value: false,
                                onChanged: null,
                              ),
                            ),
                            DataColumn(
                              label:
                                  Text("Info Produk"),
                            ),
                            DataColumn(
                              label:
                                  Text("Kategori"),
                            ),
                            DataColumn(
                              label: Text("Harga"),
                            ),
                            DataColumn(
                              label: Text("Stok"),
                            ),
                            DataColumn(
                              label: Text("Status"),
                            ),
                            DataColumn(
                              label: Text("Aksi"),
                            ),
                          ],
                          rows: [
                            _productRow(
                              "Smartwatch Series X Pro",
                              "Elektronik",
                              "Rp 2.499.000",
                              "42 Unit",
                              "Aktif",
                              Colors.green,
                            ),

                            _productRow(
                              "Sepatu Lari AeroMax 2",
                              "Fashion Pria",
                              "Rp 899.000",
                              "3 Unit",
                              "Aktif",
                              Colors.green,
                            ),

                            _productRow(
                              "Wireless Headphone Z1",
                              "Elektronik",
                              "Rp 1.250.000",
                              "0 Unit",
                              "Nonaktif",
                              Colors.grey,
                            ),
                          ],
                        ),
                      ),
                    ),

                    Container(
                      padding:
                          const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          const Text(
                            "Menampilkan 1 - 10 dari 128 produk",
                          ),

                          const Spacer(),

                          _pageButton("<"),
                          _pageButton("1",
                              active: true),
                          _pageButton("2"),
                          _pageButton("3"),

                          const Padding(
                            padding:
                                EdgeInsets.symmetric(
                              horizontal: 8,
                            ),
                            child: Text("..."),
                          ),

                          _pageButton("13"),
                          _pageButton(">"),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _statCard(
    IconData icon,
    String title,
    String value,
    Color color,
  ) {
    return Container(
      height: 90,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor:
                color.withOpacity(.15),
            child: Icon(
              icon,
              color: color,
            ),
          ),

          const SizedBox(width: 12),

          Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            mainAxisAlignment:
                MainAxisAlignment.center,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: Colors.black54,
                ),
              ),
              Text(
                value,
                style: TextStyle(
                  color: color,
                  fontSize: 28,
                  fontWeight:
                      FontWeight.bold,
                ),
              ),
            ],
          )
        ],
      ),
    );
  }

  Widget _filterButton(String text) {
    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 10,
      ),
      decoration: BoxDecoration(
        border: Border.all(
          color: Colors.grey.shade300,
        ),
        borderRadius:
            BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Text(text),
          const Icon(
            Icons.keyboard_arrow_down,
          ),
        ],
      ),
    );
  }

  DataRow _productRow(
    String product,
    String category,
    String price,
    String stock,
    String status,
    Color color,
  ) {
    return DataRow(
      cells: [
        const DataCell(
          Checkbox(
            value: false,
            onChanged: null,
          ),
        ),

        DataCell(
          Row(
            children: [
              Container(
                width: 45,
                height: 45,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius:
                      BorderRadius.circular(8),
                ),
              ),

              const SizedBox(width: 10),

              Text(product),
            ],
          ),
        ),

        DataCell(Text(category)),
        DataCell(Text(price)),
        DataCell(Text(stock)),

        DataCell(
          Container(
            padding:
                const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 4,
            ),
            decoration: BoxDecoration(
              color: color.withOpacity(.15),
              borderRadius:
                  BorderRadius.circular(20),
            ),
            child: Text(
              status,
              style: TextStyle(
                color: color,
              ),
            ),
          ),
        ),

        const DataCell(
          Row(
            children: [
              Icon(Icons.edit_outlined),
              SizedBox(width: 10),
              Icon(Icons.delete_outline),
              SizedBox(width: 10),
              Icon(Icons.more_vert),
            ],
          ),
        ),
      ],
    );
  }

  Widget _pageButton(
    String text, {
    bool active = false,
  }) {
    return Container(
      margin: const EdgeInsets.only(left: 6),
      width: 36,
      height: 36,
      decoration: BoxDecoration(
        color: active
            ? const Color(0xff1D4ED8)
            : Colors.white,
        borderRadius:
            BorderRadius.circular(8),
        border: Border.all(
          color: Colors.grey.shade300,
        ),
      ),
      child: Center(
        child: Text(
          text,
          style: TextStyle(
            color: active
                ? Colors.white
                : Colors.black,
          ),
        ),
      ),
    );
  }
}