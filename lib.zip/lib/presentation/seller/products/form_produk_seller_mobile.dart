import 'package:flutter/material.dart';
import '../profile/profile_seller_mobile.dart';

class FormProdukSellerMobile extends StatelessWidget {
  const FormProdukSellerMobile({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF5F7FB),

      body: SafeArea(
        child: Column(
          children: [
            // HEADER
            Container(
              padding: const EdgeInsets.all(20),
              color: Colors.white,
              child: Column(
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          "PasarKita",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Color(0xff2563EB),
                          ),
                        ),
                      ),

                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const SellerEditProfileMobile(),
                            ),
                          );
                        },
                        child: CircleAvatar(
                          radius: 18,
                          backgroundColor: Colors.grey.shade300,
                          child: const Icon(Icons.person),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 24),

                  Row(
                    children: [
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Produk Saya",
                              style: TextStyle(
                                fontSize: 30,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              "Kelola 24 daftar produk aktif",
                              style: TextStyle(color: Colors.grey),
                            ),
                          ],
                        ),
                      ),

                      ElevatedButton.icon(
                        onPressed: () {},
                        icon: const Icon(Icons.add, size: 18),
                        label: const Text("Tambah"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xff1E40AF),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 12,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  Row(
                    children: [
                      _filterChip("Semua", true),
                      const SizedBox(width: 8),
                      _filterChip("Aktif", false),
                      const SizedBox(width: 8),
                      _filterChip("Stok Habis", false),
                      const SizedBox(width: 8),
                      _filterChip("Arsip", false),
                    ],
                  ),
                ],
              ),
            ),

            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: const [
                  ProductCard(
                    name: "Sepatu Lari Ultra Light Pro X",
                    price: "Rp 850.000",
                    stock: "42",
                    status: "AKTIF",
                    imageIcon: Icons.directions_run,
                  ),

                  SizedBox(height: 14),

                  ProductCard(
                    name: "Wireless Headphone Noise Cancelling",
                    price: "Rp 2.400.000",
                    stock: "12",
                    status: "AKTIF",
                    imageIcon: Icons.headphones,
                  ),

                  SizedBox(height: 14),

                  ProductCard(
                    name: "Classic Leather Wristwatch",
                    price: "Rp 525.000",
                    stock: "2",
                    status: "AKTIF",
                    imageIcon: Icons.watch,
                    lowStock: true,
                  ),

                  SizedBox(height: 14),

                  ProductCard(
                    name: "Vintage Series Film Camera",
                    price: "Rp 1.250.000",
                    stock: "8",
                    status: "ARSIP",
                    imageIcon: Icons.camera_alt,
                    archive: true,
                  ),

                  SizedBox(height: 14),

                  ProductCard(
                    name: "Gold Frame Aviator Sunglasses",
                    price: "Rp 320.000",
                    stock: "Habis",
                    status: "PERLU RESTOK",
                    imageIcon: Icons.visibility,
                    outOfStock: true,
                  ),

                  SizedBox(height: 100),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _filterChip(String title, bool active) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
      decoration: BoxDecoration(
        color: active ? const Color(0xff1E40AF) : const Color(0xffDBEAFE),
        borderRadius: BorderRadius.circular(25),
      ),
      child: Text(
        title,
        style: TextStyle(
          color: active ? Colors.white : Colors.black54,
          fontWeight: active ? FontWeight.bold : null,
        ),
      ),
    );
  }
}

class ProductCard extends StatelessWidget {
  final String name;
  final String price;
  final String stock;
  final String status;
  final IconData imageIcon;

  final bool lowStock;
  final bool archive;
  final bool outOfStock;

  const ProductCard({
    super.key,
    required this.name,
    required this.price,
    required this.stock,
    required this.status,
    required this.imageIcon,
    this.lowStock = false,
    this.archive = false,
    this.outOfStock = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(imageIcon, size: 40, color: Colors.grey.shade700),
          ),

          const SizedBox(width: 14),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 17,
                  ),
                ),

                const SizedBox(height: 6),

                Text(
                  price,
                  style: const TextStyle(
                    color: Color(0xff2563EB),
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),

                const SizedBox(height: 8),

                Row(
                  children: [
                    Icon(
                      outOfStock ? Icons.warning_amber : Icons.inventory_2,
                      size: 16,
                      color: outOfStock
                          ? Colors.red
                          : lowStock
                          ? Colors.red
                          : Colors.grey,
                    ),

                    const SizedBox(width: 4),

                    Text(
                      "Stok: $stock",
                      style: TextStyle(
                        color: outOfStock || lowStock
                            ? Colors.red
                            : Colors.black54,
                        fontWeight: lowStock ? FontWeight.bold : null,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              const Icon(Icons.more_vert),

              const SizedBox(height: 28),

              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: archive
                      ? Colors.grey.shade200
                      : outOfStock
                      ? Colors.red.shade50
                      : Colors.green.shade50,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  status,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    color: archive
                        ? Colors.grey
                        : outOfStock
                        ? Colors.red
                        : Colors.green,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
