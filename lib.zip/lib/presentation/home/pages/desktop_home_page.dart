import 'package:flutter/material.dart';

import '../../../core/services/product_service.dart';
import '../../../core/widgets/product_card.dart';
import '../../../data/models/product_model.dart';
import '../../cart/cart_page.dart';
import '../../auth/login_page.dart';
import '../../profile/order_history_page.dart';
import '../../profile/profile_page.dart';

class DesktopHomePage extends StatefulWidget {
  const DesktopHomePage({super.key});

  @override
  State<DesktopHomePage> createState() => _DesktopHomePageState();
}

class _DesktopHomePageState extends State<DesktopHomePage> {
  final ProductService _productService = ProductService();

  late Future<List<ProductModel>> products;

  @override
  void initState() {
    super.initState();

    products = _productService.getProducts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,

      body: Row(
        children: [
          // ==========================
          // SIDEBAR
          // ==========================
          Container(
            width: 250,
            color: const Color(0xFF111111),

            child: Column(
              children: [
                const SizedBox(height: 40),

                const Text(
                  'PasarKita',
                  style: TextStyle(
                    color: Colors.amber,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 50),

                menuItem(
                  context,
                  icon: Icons.home,
                  title: "Home",
                  active: true,
                  onTap: () {},
                ),

                menuItem(
                  context,
                  icon: Icons.shopping_cart,
                  title: "Keranjang",
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const CartPage()),
                    );
                  },
                ),

                menuItem(
                  context,
                  icon: Icons.receipt_long,
                  title: "Pesanan Saya",
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const OrderHistoryPage(),
                      ),
                    );
                  },
                ),

                menuItem(
                  context,
                  icon: Icons.person,
                  title: "Profile",
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const ProfilePage()),
                    );
                  },
                ),

                const Spacer(),

                menuItem(
                  context,
                  icon: Icons.logout,
                  title: "Logout",
                  onTap: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (_) => const LoginPage()),
                    );
                  },
                ),

                const SizedBox(height: 30),
              ],
            ),
          ),

          // ==========================
          // CONTENT
          // ==========================
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(24),

              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,

                children: [
                  // HEADER
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          height: 50,

                          decoration: BoxDecoration(
                            color: const Color(0xFF1A1A1A),

                            borderRadius: BorderRadius.circular(12),
                          ),

                          child: const TextField(
                            style: TextStyle(color: Colors.white),

                            decoration: InputDecoration(
                              hintText: 'Cari produk...',

                              hintStyle: TextStyle(color: Colors.grey),

                              prefixIcon: Icon(
                                Icons.search,
                                color: Colors.grey,
                              ),

                              border: InputBorder.none,
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(width: 20),

                      const Icon(Icons.notifications_none, color: Colors.white),
                    ],
                  ),

                  const SizedBox(height: 40),

                  // KATEGORI
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,

                    child: Row(
                      children: [
                        categoryChip("Hoodie"),
                        categoryChip("Jacket"),
                        categoryChip("Shoes"),
                        categoryChip("T-Shirt"),
                        categoryChip("Celana"),
                      ],
                    ),
                  ),

                  const SizedBox(height: 40),

                  const Text(
                    "Produk Terbaru",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 20),

                  // ==========================
                  // FIRESTORE PRODUCTS
                  // ==========================
                  Expanded(
                    child: FutureBuilder<List<ProductModel>>(
                      future: products,

                      builder: (context, snapshot) {
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return const Center(
                            child: CircularProgressIndicator(),
                          );
                        }

                        if (snapshot.hasError) {
                          return Center(
                            child: Text('Error: ${snapshot.error}'),
                          );
                        }

                        if (!snapshot.hasData || snapshot.data!.isEmpty) {
                          return const Center(
                            child: Text('Produk tidak ditemukan'),
                          );
                        }

                        final productList = snapshot.data!;

                        return GridView.builder(
                          itemCount: productList.length,

                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 4,

                                crossAxisSpacing: 20,

                                mainAxisSpacing: 20,

                                childAspectRatio: 0.68,
                              ),

                          itemBuilder: (context, index) {
                            return ProductCard(product: productList[index]);
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget menuItem(
    BuildContext context, {
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    bool active = false,
  }) {
    return ListTile(
      leading: Icon(icon, color: active ? Colors.amber : Colors.white),

      title: Text(
        title,
        style: TextStyle(color: active ? Colors.amber : Colors.white),
      ),

      onTap: onTap,
    );
  }

  Widget categoryChip(String title) {
    return Container(
      margin: const EdgeInsets.only(right: 12),

      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),

      decoration: BoxDecoration(
        border: Border.all(color: Colors.amber),

        borderRadius: BorderRadius.circular(12),
      ),

      child: Text(title, style: const TextStyle(color: Colors.amber)),
    );
  }
}
