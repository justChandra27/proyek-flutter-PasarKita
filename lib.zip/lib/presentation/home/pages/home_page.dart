import 'package:flutter/material.dart';

import 'desktop_home_page.dart';
import 'mobile_home_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;

    // Desktop / Tablet
    if (width >= 900) {
      return const DesktopHomePage();
    }

    // Mobile
    return const MobileHomePage();
  }
}