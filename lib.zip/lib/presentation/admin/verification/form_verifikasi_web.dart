//lib/presentation/admin/verification/form_verifikasi_web.dart

import 'package:flutter/material.dart';

class FormVerifikasiWeb extends StatelessWidget {
  const FormVerifikasiWeb({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF5F6FA),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            // HEADER
            Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 48,
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: "Cari data verifikasi...",
                        prefixIcon: const Icon(Icons.search),
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                ),

                const SizedBox(width: 20),

                const CircleAvatar(
                  radius: 20,
                  backgroundImage: NetworkImage(
                    "https://i.pravatar.cc/150",
                  ),
                ),

                const SizedBox(width: 10),

                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Admin Utama",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "Super Admin",
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.black54,
                      ),
                    ),
                  ],
                ),
              ],
            ),

            const SizedBox(height: 30),

            // TITLE
            const Align(
              alignment: Alignment.centerLeft,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Verifikasi Akun",
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 6),
                  Text(
                    "Kelola persetujuan pendaftaran pengguna baru di platform PasarKita.",
                    style: TextStyle(
                      color: Colors.black54,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // STATISTIC
            Row(
              children: [
                Expanded(
                  child: _statCard(
                    icon: Icons.assignment_ind_outlined,
                    title: "Total Pending",
                    value: "128",
                    color: Colors.blue,
                  ),
                ),

                const SizedBox(width: 16),

                Expanded(
                  child: _statCard(
                    icon: Icons.storefront_outlined,
                    title: "Seller Pending",
                    value: "45",
                    color: Colors.grey,
                  ),
                ),

                const SizedBox(width: 16),

                Expanded(
                  child: _statCard(
                    icon: Icons.person_outline,
                    title: "Customer Pending",
                    value: "83",
                    color: Colors.grey,
                  ),
                ),

                const SizedBox(width: 16),

                Expanded(
                  child: Container(
                    height: 110,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: const Color(0xff2563EB),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: const Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: Colors.white24,
                          child: Icon(
                            Icons.bolt,
                            color: Colors.white,
                          ),
                        ),
                        SizedBox(width: 14),
                        Column(
                          crossAxisAlignment:
                              CrossAxisAlignment.start,
                          mainAxisAlignment:
                              MainAxisAlignment.center,
                          children: [
                            Text(
                              "Rata-rata Waktu",
                              style: TextStyle(
                                color: Colors.white70,
                              ),
                            ),
                            Text(
                              "14 Menit",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // TABLE CARD
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(22),
                      child: Row(
                        children: [
                          const Expanded(
                            child: Text(
                              "Daftar Antrean",
                              style: TextStyle(
                                fontSize: 26,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),

                          OutlinedButton.icon(
                            onPressed: () {},
                            icon: const Icon(Icons.filter_alt_outlined),
                            label: const Text("Filter"),
                          ),

                          const SizedBox(width: 10),

                          OutlinedButton.icon(
                            onPressed: () {},
                            icon: const Icon(Icons.download_outlined),
                            label: const Text("Export"),
                          ),
                        ],
                      ),
                    ),

                    const Divider(height: 1),

                    Expanded(
                      child: SingleChildScrollView(
                        child: DataTable(
                          headingRowColor:
                              WidgetStateProperty.all(
                            const Color(0xffF8F9FC),
                          ),
                          columns: const [
                            DataColumn(label: Text("Nama")),
                            DataColumn(label: Text("Email")),
                            DataColumn(label: Text("Tipe")),
                            DataColumn(label: Text("Tanggal Daftar")),
                            DataColumn(label: Text("Action")),
                          ],
                          rows: [
                            _row(
                              "BS",
                              "Budi Santoso",
                              "budi.santoso@email.com",
                              "Seller",
                              "12 Okt 2023, 10:45",
                            ),
                            _row(
                              "AL",
                              "Ani Lestari",
                              "ani.les@provider.id",
                              "Customer",
                              "12 Okt 2023, 11:15",
                            ),
                            _row(
                              "WJ",
                              "Warung Jaya Makmur",
                              "jaya.makmur@business.com",
                              "Seller",
                              "12 Okt 2023, 09:20",
                            ),
                            _row(
                              "RM",
                              "Rian Mahendra",
                              "rian.mahen@mail.com",
                              "Customer",
                              "11 Okt 2023, 22:30",
                            ),
                          ],
                        ),
                      ),
                    ),

                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 18,
                      ),
                      child: Row(
                        children: [
                          const Text(
                            "Menampilkan 4 dari 128 entri",
                          ),
                          const Spacer(),

                          _pageButton("1", true),
                          _pageButton("2", false),
                          _pageButton("3", false),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _statCard({
    required IconData icon,
    required String title,
    required String value,
    required Color color,
  }) {
    return Container(
      height: 110,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 24,
            backgroundColor: color.withOpacity(.15),
            child: Icon(icon, color: color),
          ),

          const SizedBox(width: 14),

          Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            mainAxisAlignment:
                MainAxisAlignment.center,
            children: [
              Text(title),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          )
        ],
      ),
    );
  }

  DataRow _row(
    String avatar,
    String name,
    String email,
    String role,
    String date,
  ) {
    return DataRow(
      cells: [
        DataCell(
          Row(
            children: [
              CircleAvatar(
                backgroundColor:
                    Colors.blue.withOpacity(.15),
                child: Text(
                  avatar,
                  style: const TextStyle(
                    color: Colors.blue,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Text(name),
            ],
          ),
        ),

        DataCell(Text(email)),

        DataCell(
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 6,
            ),
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(role),
          ),
        ),

        DataCell(Text(date)),

        DataCell(
          Row(
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor:
                      const Color(0xff2563EB),
                ),
                onPressed: () {},
                child: const Text(
                  "Setujui",
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
              ),

              const SizedBox(width: 8),

              OutlinedButton(
                onPressed: () {},
                child: const Text(
                  "Tolak",
                  style: TextStyle(
                    color: Colors.red,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _pageButton(
    String text,
    bool active,
  ) {
    return Container(
      margin: const EdgeInsets.only(left: 8),
      width: 36,
      height: 36,
      decoration: BoxDecoration(
        color: active
            ? const Color(0xff2563EB)
            : Colors.transparent,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Center(
        child: Text(
          text,
          style: TextStyle(
            color: active
                ? Colors.white
                : Colors.black87,
          ),
        ),
      ),
    );
  }
}