import 'package:flutter/material.dart';

import '../cart/cart_page.dart';
import '../home/pages/home_page.dart';
import '../profile/profile_page.dart';

class NavigationPage extends StatefulWidget {
  const NavigationPage({super.key});

  @override
  State<NavigationPage> createState() =>
      _NavigationPageState();
}

class _NavigationPageState
    extends State<NavigationPage> {

  int currentIndex = 0;

  final pages = const [
    HomePage(),
    CartPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {

    final width =
        MediaQuery.of(context).size.width;

    // =========================
    // DESKTOP MODE
    // =========================
    if (width >= 900) {
      return pages[currentIndex];
    }

    // =========================
    // MOBILE MODE
    // =========================
    return Scaffold(

      body: pages[currentIndex],

      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,

        backgroundColor: Colors.black,

        selectedItemColor:
            const Color(0xFFD4AF37),

        unselectedItemColor: Colors.grey,

        onTap: (index) {
          setState(() {
            currentIndex = index;
          });
        },

        items: const [

          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart),
            label: "Cart",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: "Profile",
          ),
        ],
      ),

      floatingActionButton:
          FloatingActionButton(

        backgroundColor:
            const Color(0xFFD4AF37),

        child: const Icon(
          Icons.add,
          color: Colors.black,
        ),

        onPressed: () {
          Navigator.pushNamed(
            context,
            '/add-product',
          );
        },
      ),
    );
  }
}