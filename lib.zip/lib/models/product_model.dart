class ProductModel {
  final String id;
  final String name;
  final int price;
  final String description;
  final String imageUrl;
  final int stock;
  final String category;

  ProductModel({
    required this.id,
    required this.name,
    required this.price,
    required this.description,
    required this.imageUrl,
    required this.stock,
    required this.category,
  });

  factory ProductModel.fromFirestore(
    Map<String, dynamic> data,
    String documentId,
  ) {
    return ProductModel(
      id: documentId,
      name: data['name'] ?? '',
      price: data['price'] ?? 0,
      description: data['description'] ?? '',
      imageUrl: data['imageUrl'] ?? '',
      stock: data['stock'] ?? 0,
      category: data['category'] ?? '',
    );
  }
}