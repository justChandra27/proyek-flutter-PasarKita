import 'package:flutter/material.dart';

import '../models/product_model.dart';
import '../services/product_service.dart';
import '../screens/add_product_page.dart';
import '../screens/edit_product_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final ProductService _productService = ProductService();

  late Future<List<ProductModel>> products;

  @override
  void initState() {
    super.initState();

    products = _productService.getProducts();
  }

  void refreshProducts() {
    setState(() {
      products = _productService.getProducts();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('PasarKita')),

      body: FutureBuilder<List<ProductModel>>(
        future: products,

        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('Produk kosong'));
          }

          final productList = snapshot.data!;

          return ListView.builder(
            itemCount: productList.length,

            itemBuilder: (context, index) {
              final product = productList[index];

              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),

                child: ListTile(
                  leading: Image.asset(
                    product.imageUrl,
                    width: 60,
                    height: 60,
                    fit: BoxFit.cover,
                  ),

                  title: Text(product.name),

                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,

                    children: [
                      Text('Rp ${product.price}'),

                      const SizedBox(height: 4),

                      Text(product.category),
                    ],
                  ),

                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,

                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit),

                        onPressed: () {
                          Navigator.push(
                            context,

                            MaterialPageRoute(
                              builder: (_) => EditProductPage(product: product),
                            ),
                          ).then((_) {
                            refreshProducts();
                          });
                        },
                      ),

                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),

                        onPressed: () async {
                          await _productService.deleteProduct(product.id);

                          refreshProducts();
                        },
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),

      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,

            MaterialPageRoute(builder: (_) => const AddProductPage()),
          ).then((_) {
            refreshProducts();
          });
        },

        child: const Icon(Icons.add),
      ),
    );
  }
}
