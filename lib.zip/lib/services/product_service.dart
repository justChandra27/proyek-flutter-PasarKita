import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/product_model.dart';

class ProductService {
  final FirebaseFirestore _firestore =
      FirebaseFirestore.instance;

  Future<List<ProductModel>> getProducts() async {
    QuerySnapshot snapshot =
        await _firestore.collection('products').get();

    return snapshot.docs.map((doc) {
      return ProductModel.fromFirestore(
        doc.data() as Map<String, dynamic>,
        doc.id,
      );
    }).toList();
  }

  Future<void> addProduct({
    required String name,
    required int price,
    required String description,
    required int stock,
    required String category,
  }) async {
    await _firestore.collection('products').add({
      'name': name,
      'price': price,
      'description': description,
      'imageUrl': '',
      'stock': stock,
      'category': category,
    });
  }
  Future<void> updateProduct({
  required String id,
  required String name,
  required int price,
  required String description,
  required int stock,
  required String category,
}) async {

  await _firestore
      .collection('products')
      .doc(id)
      .update({
    'name': name,
    'price': price,
    'description': description,
    'stock': stock,
    'category': category,
  });
}

Future<void> deleteProduct(String id) async {

  await _firestore
      .collection('products')
      .doc(id)
      .delete();
}
}